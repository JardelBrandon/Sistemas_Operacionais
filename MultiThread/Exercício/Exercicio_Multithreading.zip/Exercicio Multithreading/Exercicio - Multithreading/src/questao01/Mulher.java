package questao01;

public class Mulher extends Pessoa 
{
	private static String DESEJO = "SAPATOS!";

	public String getDesejo() 
	{	return DESEJO;
	}
}

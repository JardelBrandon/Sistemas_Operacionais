package questao01;

public class Homem extends Pessoa 
{
	private static String DESEJO = "CERVEJAS!";

	public String getDesejo() 
	{	return DESEJO;
	}
}

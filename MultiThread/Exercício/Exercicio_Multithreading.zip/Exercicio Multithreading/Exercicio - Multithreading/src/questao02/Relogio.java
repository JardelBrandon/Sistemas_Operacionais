package questao02;

public interface Relogio 
{	
	public void horaMudou(int novaHora);

	public void minutoMudou(int novoMinuto);
}
